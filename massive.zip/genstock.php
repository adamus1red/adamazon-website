<?php
    include_once("includes/config.php");
    include_once("includes/mysql.php");
    $oMySQL = new MySQL($config['mysql_database'], $config['mysql_user'], $config['mysql_pass'], $config['mysql_host']);
	$max = 100;
for($j = 1; $j < 3; $j++) {
    $r1 = Rand(0, $max);
    $r2 = Rand(0, $max);
    $r3 = Rand(0, $max);
    $r4 = Rand(0, $max);
    $r5 = Rand(0, $max);
    $r6 = Rand(0, $max);
    $r7 = Rand(0, $max);
    $r8 = Rand(0, $max);
    $r9 = Rand(0, $max);
    $r10 = Rand(0, $max);
    if($j = 0){
        $size = "S";
    }elseif($j = 1) {
        $size = "M";
    } else { 
        $size = "L"; 
    }
$sql = "INSERT INTO `items` (`prodID`, `name`, `description`, `productImage`, `price`, `active`) VALUES
({$j}1, 'Offensive t-Shirt', 'This t-shirt will annoy your friends', '/images/product/001.png', 99.99, 1, {$size}, {$r1}),
(({$j}2, 'Cloud sick', 'Save tha planet!', '/images/product/002.jpg', 9999.10, 1, {$size}, {$r1}),
(({$j}3, 'Patrick made a friend ', 'Who''s riding a sloth under the sea?<br />\r\nPatrick Starfish!', '/images/product/003.png', 5.99, 1, {$size}, {$r1}),
(({$j}4, 'Alchemy ', 'Warning: Try not to lose your body due to equivalent exchange.', '/images/product/004.jpg', 5.99, 1, {$size}, {$r1}),
(({$j}5, 'Munchies', 'Need food?<br /> Why not M & M''s', '/images/product/005.png', 10.99, 1, {$size}, {$r1}),
(({$j}6, 'Triple Pack', 'Need more than one t-shirt?<br />Why not have 3!', '/images/product/006.jpg', 59.99, 1, {$size}, {$r1}),
(({$j}7, 'Generic T Shirt', 'Generic Blah Blah Blah', '/images/product/007.jpg', 10.99, 1, {$size}, {$r1}),
(({$j}8, 'Girls T Shirt', 'All girly and stuff', '/images/product/008.jpg', 11.99, 1, {$size}, {$r1}),
(({$j}9, 'Manly Man''s T Shirt', 'Are you man enough for the t shirt?', '/images/product/009.png', 99.99, 1, {$size}, {$r1}),
(({$j}10, 'Awesome T Shirt', 'EVERYTHING IS AWESOME!', '/images/product/010.jpg', 50.53, 1, {$size}, {$r1})";

    $oMySQL->executeSQL($sql);
}
?>