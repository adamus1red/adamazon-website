<?php
    include_once("includes/config.php");
    include_once("includes/mysql.php");
   $site_page_title = "Not Found";
   include("includes/header.php");
    include("includes/heading.php")
?>
	<h1>Nothing Found. Try again later</h1>
<?php
	include("includes/footer.php");
?>