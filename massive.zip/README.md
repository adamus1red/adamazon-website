massive-octo-dubstep
====================

CS312 Group Project - Shopping Site

* Thomas Sinclair - mlb12174
* Adam McGhie - rgb12180
* Grant Toghill - wsb12157
* Darren Tang - pjb12147

---

# TODO

[See the issues page](https://github.com/adamus1red/massive-octo-dubstep/issues)

---

Icons provided by http://glyphicons.com/

mySQL class provided by Ed Rackham (http://github.com/a1phanumeric/PHP-MySQL-Class)
