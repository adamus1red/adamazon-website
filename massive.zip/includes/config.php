<?php

$config = parse_ini_file("config.ini");

?>
